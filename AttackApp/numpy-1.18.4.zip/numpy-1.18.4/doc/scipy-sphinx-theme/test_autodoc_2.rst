scipy.interpolate.griddata
==========================

.. currentmodule:: scipy.interpolate

.. autofunction:: scipy.interpolate.griddata
